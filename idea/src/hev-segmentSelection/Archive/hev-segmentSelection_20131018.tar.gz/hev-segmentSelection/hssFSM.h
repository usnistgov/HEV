

#ifndef __HSSFSM_H__
#define __HSSFSM_H__

void getStoredCursorLocation (float pos[3]);

void runFiniteStateMachine ();

void setSleep (unsigned long uslp);


#endif    // __HSSFSM_H__

