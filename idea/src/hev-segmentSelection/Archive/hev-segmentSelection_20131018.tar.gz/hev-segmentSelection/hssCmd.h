

#ifndef _HEV_SEG_SEL_CMD_H_
#define _HEV_SEG_SEL_CMD_H_

int processCommands ();
int setupCmdFifo ();

#endif   // _HEV_SEG_SEL_CMD_H_


