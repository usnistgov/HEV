#!/bin/sh
# put up a window with the probe's position in world coordinates
coord=`hev-matrixToCoord --xyz idea/worldOffsetWand`
echo -e "wand pointer at:\n $coord" | hev-messageBox $IRISFLY_MCP_X11_IMMERSIVE_OPTIONS -title probe@ --rows 2 --columns 40 & pid=$!
echo KILL $pid > $IRIS_CONTROL_FIFO

