#!/bin/sh
# need to keep hev-matrixToCoord writing to the pipe so we'll exit on a broken pipe
hev-matrixToCoord --xyz --loop --every --usleep 10000 idea/worldOffsetWand | hev-messageBox $IRISFLY_MCP_X11_IMMERSIVE_OPTIONS -title probe --rows 1 --columns 40 --noescape --dynamic& pid=$!
echo KILL $pid > $IRIS_CONTROL_FIFO

