#include <osgDB/Registry>

USE_DOTOSGWRAPPER(Text_Proxy)
USE_DOTOSGWRAPPER(Text3D_Proxy)
USE_DOTOSGWRAPPER(TextBase_Proxy)

extern "C" void dotosgwrapper_library_osgText(void) {}

