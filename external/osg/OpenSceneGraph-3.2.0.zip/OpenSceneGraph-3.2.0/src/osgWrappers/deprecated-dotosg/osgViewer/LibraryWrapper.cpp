#include <osgDB/Registry>

USE_DOTOSGWRAPPER(CompositeViewer_Proxy)
USE_DOTOSGWRAPPER(View_Proxy)
USE_DOTOSGWRAPPER(Viewer_Proxy)

extern "C" void dotosgwrapper_library_osgViewer(void) {}

