#include <errno.h>

int main()
{
    int value = ENAMETOOLONG;
    return 0;
}
