int main()
{
    int n = 42;
    int foo[n];
    return 0;
}
