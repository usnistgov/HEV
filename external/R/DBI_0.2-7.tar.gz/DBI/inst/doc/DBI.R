### R code from vignette source 'DBI.Rnw'

