/* fall-back setting on Widnows */

/* assume Sun/Oracle JVM which supports -Xrs */
#define HAVE_XRS 1
