#ifdef RSQLITE_USE_BUNDLED_SQLITE
#  include "sqlite/sqlite3.h"
#else
#  include <sqlite3.h>
#endif
